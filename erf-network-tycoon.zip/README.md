# ERF Network Tycoon — playable drag-and-connect prototype

This is version 0.2, a standalone browser game made with vanilla HTML, CSS and JavaScript. No libraries or server are necessary.

## Play locally

Open `index.html` in Chrome, Safari, Edge or Firefox. Your game saves automatically in that browser via `localStorage`.

## Put it on GitHub Pages

1. Make a new public repository at https://github.com/new (e.g. `erf-network-tycoon`).
2. Upload `index.html` into the repository's root.
3. Go to **Settings → Pages → Build and deployment**.
4. Select **Deploy from a branch**, `main`, and `/ (root)`; save.
5. GitHub will provide a Pages URL after deployment.

## Gameplay

- Start with only a waste reception block and a small amount of capital.
- Build equipment by dragging catalogue cards onto the board or pressing **Add**.
- Drag installed blocks by their headers to rearrange the process flow.
- Connect a block's **right-hand output port** to a compatible **left-hand input port**.
- Click an existing connection to remove it.
- Complete waste, flue gas, feedwater and steam routes to generate revenue and power.
- Earn construction grants for completed system milestones and upgrade each block separately.
- Choose MARTIN reverse-acting grate **or** DynaGrate® as alternative combustion technologies, each with different capacity/power bonuses. Upgrade the steam boiler independently.
- Build ash handling, ash treatment and metal recovery; add turbine, grid and ACC for later production.
- Save automatically, export a save backup or start a new game.

## Current limitations

- This is deliberately a small game prototype. Process capacities, money rates and equipment prices are fictional gameplay values rather than operating data.
- It is single-player and local-save only. No multiplayer, backend, market system or cloud saves.
- Layout is a free-form node editor with fixed process port compatibility, not a full plant simulator.
- Each equipment type can be placed once; multiple lines and repeated equipment will be future features.

## Next version ideas

Commission multiple waste lines; equipment breakdowns and planned outages; separate SNCR, reactor, baghouse and conditioning tower; optional scrubber and heat export; combustion tuning; landfill diversion; metal recycling contracts; control room dashboard; deeper research tree; different boiler arrangements; process alarm panels.
